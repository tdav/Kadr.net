﻿namespace rep01
{
    partial class frmReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReport));
            this.btnRun = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grOwner = new DevExpress.XtraEditors.RadioGroup();
            this.label1 = new System.Windows.Forms.Label();
            this.edDrb = new DevExpress.XtraEditors.TextEdit();
            this.edLog = new DevExpress.XtraEditors.MemoEdit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grOwner.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edDrb.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edLog.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRun
            // 
            this.btnRun.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRun.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRun.Location = new System.Drawing.Point(397, 10);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(154, 41);
            this.btnRun.TabIndex = 1;
            this.btnRun.Text = "Ҳисоблаш";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.grOwner);
            this.panel1.Controls.Add(this.btnRun);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.edDrb);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(564, 60);
            this.panel1.TabIndex = 4;
            // 
            // grOwner
            // 
            this.grOwner.EditValue = 0;
            this.grOwner.Location = new System.Drawing.Point(16, 15);
            this.grOwner.Name = "grOwner";
            this.grOwner.Properties.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.grOwner.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grOwner.Properties.Appearance.Options.UseBackColor = true;
            this.grOwner.Properties.Appearance.Options.UseFont = true;
            this.grOwner.Properties.Columns = 2;
            this.grOwner.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(0, "Шахсий"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(1, "Давлат")});
            this.grOwner.Size = new System.Drawing.Size(192, 29);
            this.grOwner.TabIndex = 4;
            this.grOwner.SelectedIndexChanged += new System.EventHandler(this.grOwner_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(221, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Дрб";
            // 
            // edDrb
            // 
            this.edDrb.Location = new System.Drawing.Point(260, 17);
            this.edDrb.Name = "edDrb";
            this.edDrb.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.edDrb.Properties.Appearance.Options.UseFont = true;
            this.edDrb.Properties.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.edDrb.Properties.Mask.EditMask = "[0-9][0-9][A-Z]___[A-Z][A-Z]";
            this.edDrb.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
            this.edDrb.Size = new System.Drawing.Size(127, 26);
            this.edDrb.TabIndex = 0;
            // 
            // edLog
            // 
            this.edLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.edLog.Location = new System.Drawing.Point(0, 60);
            this.edLog.Name = "edLog";
            this.edLog.Size = new System.Drawing.Size(564, 415);
            this.edLog.TabIndex = 5;
            // 
            // frmReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 475);
            this.Controls.Add(this.edLog);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmReport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Радар";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grOwner.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edDrb.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edLog.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.TextEdit edDrb;
        private DevExpress.XtraEditors.RadioGroup grOwner;
        private DevExpress.XtraEditors.MemoEdit edLog;
    }
}