﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ManagedExcel;
using System.ServiceModel;

using Asbt.Utils;
using Asbt.PVOnlineWorks;

namespace rep01
{
    public partial class frmReport : Form
    {
        public frmReport()
        {
            InitializeComponent();
        }

        private string SetZero(int s)
        {
            if (s > 99)
                return s.ToStr();

            if (s < 10)
                return "00" + s.ToStr();
            else
                return "0" + s.ToStr();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            string s;
            string sx;
            string drbm = edDrb.Text.Replace("___", "{0}");  
            int l;

            edLog.Text = "";
            btnRun.Enabled = false;
            string[] val = new string[2];

            val[0] = " select distinct t.tb_gosnum from TB_TEXP t where  t.tb_gosnum like " + edDrb.Text.ToQuote() +
                         " and t.tb_owner = " + grOwner.SelectedIndex.ToStr();

            DataTable dt = ClassOnlineWorks.GetProcedureDataTable(val, "TEXP.FORM_WORKS.RemoteSqlExec");


            WaitFormManager.Show();

            if (dt.Rows.Count == 0) { MessageBox.Show("Маълумот йўқ..."); return; }
            dt.DefaultView.Sort = "TB_GOSNUM";
            dt = dt.DefaultView.ToTable();


            List<string> sl = new List<string>();
            foreach (DataRow item in dt.Rows)
            {
                s = item[0].ToStr();
                s = s.Substring(2).ToUpper();
                l = s.Length;

                sx = "";
                for (int i = 0; i < l; i++)
                {
                    if (Char.IsDigit(s[i]))
                        sx += s[i];
                }
                sl.Add(sx);
            }

            if (sl.Count == 0) return;

            for (int i = 10; i < 999; i++)
            {
                switch (i)
                {
                    case 111:
                    case 222:
                    case 333:
                    case 444:
                    case 555:
                    case 666:
                    case 777:
                    case 888:
                    case 999:
                    case 100:
                    case 200:
                    case 300:
                    case 400:
                    case 500:
                    case 600:
                    case 700:
                    case 800:
                    case 900: continue;
                }

                
                sx = SetZero(i);
                if (sl.IndexOf(sx) ==-1)
                    edLog.Text += String.Format("\t" + drbm, sx);
            }
            WaitFormManager.Close();
            btnRun.Enabled = true;
        }


      
        private void grOwner_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (grOwner.SelectedIndex == 0)
            {
                edDrb.Properties.Mask.EditMask = "[0-9][0-9][A-Z]___[A-Z][A-Z]";
                edDrb.Text = "";
            }
            else
            {
                edDrb.Properties.Mask.EditMask = "[0-9][0-9]___[A-Z][A-Z][A-Z]";
                edDrb.Text = "";
            }

            //01947KDA
        }


    }
}