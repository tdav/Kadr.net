﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ManagedExcel;
using DevExpress.XtraEditors;
using System.ServiceModel;

using Asbt.Utils;
using Asbt.PVOnlineWorks;

namespace rep01
{
    public partial class frmReport : Form
    {
        public frmReport()
        {
            InitializeComponent();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            string val = "";

            foreach (string si in lbList.Items)
            {
                if (val != "")
                {
                    val += ",";
                }
                val += si.ToQuote();
            }

            string[] sv = new string[2] { val, "" };
            DataTable dt = ClassOnlineWorks.GetProcedureDataTable(sv, "TEXP.FORM_WORKS.GetRadarList");
            ExportExcel(dt);
        }


        public void ExportExcel(DataTable dt)
        {
            using (ManagedExcel.Application app = ManagedExcel.ExcelApplication.Create())
            {   
                using (Workbook wb = app.Workbooks.Add(Type.Missing))
                {
                    wb.Title = "new workbook";
                    using (Worksheets worksheets = wb.Sheets)
                    {
                        int count_sheets = worksheets.Count; //try to get count of sheets
                        using (Worksheet ws = wb.Sheets[1])
                        {
                            //Range usedrange = ws.UsedRange; //try to get used range

                            int i = 1;
                            ws.Cells[i, 1].Value = "ДРБ";
                            ws.Cells[i, 2].Value = "Тех. сер";
                            ws.Cells[i, 3].Value = "Тех. №";
                            ws.Cells[i, 4].Value = "Тв тури";
                            ws.Cells[i, 5].Value = "Тв русуми";
                            ws.Cells[i, 6].Value = "Ранги";
                            ws.Cells[i, 7].Value = "Йил";
                            ws.Cells[i, 8].Value = "ФИШ";
                            ws.Cells[i, 9].Value = "Туғ. сана";
                            ws.Cells[i, 10].Value = "Телефон";
                            ws.Cells[i, 11].Value = "Вилоят";
                            ws.Cells[i, 12].Value = "Туман";
                            ws.Cells[i, 13].Value = "Манзил";
                            ws.Cells[i, 14].Value = "Жараён";
                            ws.Cells[i, 15].Value = "Рўйхатлаш сана";
                            ws.Cells[i, 16].Value = "Двиг №";
                            ws.Cells[i, 17].Value = "Кузов №";
                            ws.Cells[i, 18].Value = "Шасси №";
                            ws.Cells[i, 19].Value = "Кушимча маъл.";
                            ws.Cells[i, 20].Value = "Карт. холати";
                            ws.Cells[i, 21].Value = "Тегиш";
                            ws.Cells[i, 22].Value = "Ходати";
                            ws.Cells[i, 23].Value = "Ишинчнома";
                            
                            i++;

                            foreach (DataRow r in dt.Rows)
                            {
                                ws.Cells[i, 1].Value = r["TB_GOSNUM"].ToStr();
                                ws.Cells[i, 2].Value = r["TB_SERY"].ToStr();
                                ws.Cells[i, 3].Value = r["TB_NUMBER"].ToStr();
                                ws.Cells[i, 4].Value = r["KUZOV"].ToStr();
                                ws.Cells[i, 5].Value = r["MARKA"].ToStr();
                                ws.Cells[i, 6].Value = r["COLOR"].ToStr();
                                ws.Cells[i, 7].Value = r["CAR_YEAR"].ToStr();
                                ws.Cells[i, 8].Value = r["FIO"].ToStr();
                                ws.Cells[i, 9].Value = r["TB_DATEBIRTH"].ToStr();
                                ws.Cells[i, 10].Value = r["TB_TEL"].ToStr();
                                ws.Cells[i, 11].Value = r["OBLAST"].ToStr();
                                ws.Cells[i, 12].Value = r["RAYON"].ToStr();
                                ws.Cells[i, 13].Value = r["MAZIL"].ToStr();
                                ws.Cells[i, 14].Value = r["JARAYON"].ToStr();
                                ws.Cells[i, 15].Value = r["TB_DATEREG"].ToStr();
                                ws.Cells[i, 16].Value = r["TB_MOTORNUM"].ToStr();
                                ws.Cells[i, 17].Value = r["TB_KUZOVNUM"].ToStr();
                                ws.Cells[i, 18].Value = r["TB_SHASSINUM"].ToStr();
                                ws.Cells[i, 19].Value = r["TB_COMMENT"].ToStr();
                                ws.Cells[i, 20].Value = r["TB_ACTIVE"].ToStr();
                                ws.Cells[i, 21].Value = r["CARDTYPE"].ToStr();
                                ws.Cells[i, 22].Value = r["TB_DOCKIND"].ToStr();
                                ws.Cells[i, 23].Value = r["OWNFIO"].ToStr();

                                i++;
                            }
                        }
                        // wb.Saved = true;
                        // wb.Close();
                    }
                    app.Visible = true; // make excel visible
                    // app.Quit();
                }
            }
        }

        private void frmReport_FormClosing(object sender, FormClosingEventArgs e)
        {
            // client.ExecRSPluginCompleted -= OnClientExecRSPluginCompleted;
            //  client.Close();
        }

        private void lbList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete && lbList.SelectedIndex > -1)
                lbList.Items.RemoveAt(lbList.SelectedIndex);
        }

        private void edDrb_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                lbList.Items.Add(edDrb.Text);
                edDrb.Text = "";
            }
        }
    }
}