﻿using Asbt.Global;
using Asbt.Utils;
using ManagedExcel;
using System;
using System.Data;
using System.Windows.Forms;
using Asbt.DictionaryDB;


namespace rep01
{
    public partial class frmRepMain : Form
    {
        public frmRepMain()
        {
            InitializeComponent();  
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            progressBarControl1.Properties.Step = 1;
            progressBarControl1.Properties.PercentView = true;
          //  progressBarControl1.Properties.Maximum = myTable.Rows.Count;
            progressBarControl1.Properties.Minimum = 0;
            string[] p = new string[4];
            p[0] = edDate1.Text;
            p[1] = edDate2.Text;
            p[2] = GlobalVars.DivisionId;

            DataTable dt = DicoDB.dt_SA_HARBIY_UNVON;
            ToExcel(dt);
        }

        void ToExcel(DataTable dt)
        {
            using (ManagedExcel.Application app = ExcelApplication.Create())
            {
                using (Workbook wb = app.Workbooks.Add(AppDomain.CurrentDomain.BaseDirectory + "form10.xlt"))
                {
                    wb.Title = "new workbook";
                    using (Worksheets worksheets = wb.Sheets)
                    {
                        using (Worksheet ws = worksheets[1])
                        {
                            using (Range cells = ws.Cells)
                            {
                                for (int j = 0; j < dt.Columns.Count; j++)
                                {
                                    cells[1, j + 1].Value = dt.Columns[j].ColumnName;
                                }

                                for (int i = 0; i < dt.Rows.Count; i++)
                                {
                                    for (int j = 0; j < dt.Columns.Count; j++)
                                    {
                                        cells[i + 2, j + 1].Value = dt.Rows[i][j].ToStr();
                                    }
                                }
                            }
                        }
                    }

                    //  wb.Saved = true;
                    //  wb.Close();
                }
                app.Visible = true; // make excel visible
            }
            MessageBox.Show("Ok");
        }

    }
}