﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraBars;
using Asbt.PluginManager;
using System.Diagnostics;
using System.Reflection;

namespace rep01
{
    public class rep01 : IPlugin, IDisposable
    {
        private BarButtonItem btn;

        public string Version
        {
            get
            {
                return Assembly.GetAssembly(typeof(rep01)).GetName().Version.ToString();
            }
        }

        public string Description
        {
            get { return "Форма 01"; }
        }

        public string FullDescription
        {
            get { return "Excel даги маълумотлар билан солиштириш"; }
        }

        public object Initialize(object MainContainer, string conStr)
        {
            btn = new DevExpress.XtraBars.BarButtonItem();
            btn.Caption = Description;
            btn.ItemClick += OnItemClick;
            btn.Hint = FullDescription + Environment.NewLine + "Версия " + Version.ToString();
            return btn;
        }

        void OnItemClick(object sender, ItemClickEventArgs e)
        {
            frmRepMain frm = new frmRepMain();
            frm.Text = FullDescription;
            frm.ShowDialog();
            frm.Dispose();
        }

        public void Dispose()
        {
            btn.ItemClick -= OnItemClick;
            btn.Dispose();
        }
    }
}
